
* Vielen Dank fuer die Nutzung FavIcon Generators!  Hier die Inhalte der ZIP-Datei:

  favicon.ico  --  Die favicon Datei (unterstuetzt 16*16 und 32*32 Abmessung).

  * Um das favicon.ico auf Ihrer Webseite einzufuegen laden Sie die Grafik favicon.ico in das Rootverzeichnis
    Ihrer Webseite und fuegen folgenden Code zwischen den <head> ... </head>
    Tags Ihrer index.html /php ein.

      <link rel="shortcut icon" href="favicon.ico">

  * Zur Verwendung des animierten FavIcon: Wenn Sie das animierte FavIcon nutzen wollen, muessen Sie auch die Datei
    animated_favicon1.gif hochladen und die folgenden HTML tags einfuegen:

      <link rel="shortcut icon" href="favicon.ico" >
      <link rel="icon" href="animated_favicon1.gif" type="image/gif" >


* Weitere Inhalte der ZIP-Datei:

  * Die folgenden Dateien sind ebenfalls in der ZIP Datei enthalten. Es handelt sich hier un zusaetzliche Inhalte:

    - favicon.ico - favicon.
    - preview_16x16.png - 16*16 PNG Bild des favicon.
    - preview_32x32.png - 32*32 PNG Bild des favicon.
    - animated_favicon.gif - animierte Version de favicon.
    - readme.txt - diese Kurzbeschreibung.
