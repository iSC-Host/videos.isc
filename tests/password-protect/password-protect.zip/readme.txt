
------------------------------------------------------------------------------
  PHP Simple PasswordProtect v1.0 
------------------------------------------------------------------------------

 Freelance Web Developer and  PHP, Perl and Javascript programming
Web:  www.stevedawson.com
Written by Steve Dawson
More great free PHP scripts online at www.stevedawson.com

-------------------------------------------------------------------------------
  INSTALLATION
-------------------------------------------------------------------------------


Quick installation guide, edit the index.php file and change the password to suit,

Add the content you want to have protected in the correct section which is fully marked.

Upload the file to your web server and then point your browser to the uploaded file and try it out.

For a more in depth look at this script please visit the article section at www.stevedawson.com





THIS SCRIPT IS AS IS. UNDER NO CIRCUMSTANCES CAN I BE HELD
RESPONSIBLE FOR ANYTHING TO DO WITH THIS SCRIPT OR ANYTHING
ELSE THAT HAPPENS IN THIS WORLD.